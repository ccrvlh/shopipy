# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyshopify',
 'pyshopify.resources.auth',
 'pyshopify.resources.collections',
 'pyshopify.resources.customers',
 'pyshopify.resources.fulfillment',
 'pyshopify.resources.inventory',
 'pyshopify.resources.orders',
 'pyshopify.resources.products',
 'pyshopify.resources.shipping',
 'pyshopify.resources.transactions',
 'pyshopify.resources.webhooks']

package_data = \
{'': ['*']}

install_requires = \
['pydantic>=1.8.2,<2.0.0', 'requests>=2.26.0,<3.0.0']

setup_kwargs = {
    'name': 'pyshopify',
    'version': '0.1.0',
    'description': 'An alternative wrapper to the Shopify API.',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
