class CredentialsError(Exception):
    pass

class InvalidSetup(Exception):
    pass